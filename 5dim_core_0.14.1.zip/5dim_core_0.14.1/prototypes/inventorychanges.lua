--Inventory large
data.raw["player"]["player"].inventory_size = 100
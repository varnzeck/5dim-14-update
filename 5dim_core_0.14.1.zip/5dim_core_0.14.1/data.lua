require("config")

--Item
if stackchanges == true then
require("prototypes.stackchanges")
end
if inventorychanges == true then
require("prototypes.inventorychanges")
end
--Item group
require("prototypes.item-groups-automatization")
require("prototypes.item-group-changes")
require("prototypes.item-groups-energy")
require("prototypes.item-groups-logistic")
require("prototypes.item-groups-mining")
require("prototypes.item-groups-module")
require("prototypes.item-groups-nuclear")
require("prototypes.item-groups-transport")
require("prototypes.item-groups-trains")
require("prototypes.item-groups-decorative")
require("prototypes.item-groups-vehicles")
require("prototypes.item-groups-armor")
require("prototypes.item-groups-plates")
require("prototypes.item-groups-intermediate")
require("prototypes.item-groups-defense")
require("prototypes.item-groups-liquids")
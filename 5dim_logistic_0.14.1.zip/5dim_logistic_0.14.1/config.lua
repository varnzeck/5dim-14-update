--Define if logistic is installed
logistic = true --Default: True
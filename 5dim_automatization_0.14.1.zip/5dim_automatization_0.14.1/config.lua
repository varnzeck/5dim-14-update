--Define if automatization is installed
automatization = true --Default: True